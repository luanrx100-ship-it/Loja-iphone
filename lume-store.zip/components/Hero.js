"use client";

import { useRef, useState } from "react";
import { useReveal } from "./useReveal";
import WhatsAppIcon, { waLink } from "./WhatsAppIcon";

const COLORS = [
  { hex: "#C9B79C", name: "Titânio Natural" },
  { hex: "#7C8792", name: "Titânio Preto" },
  { hex: "#B08A5A", name: "Titânio Deserto" },
  { hex: "#5B93C4", name: "Titânio Azul" },
];

export default function Hero() {
  const r1 = useReveal();
  const r2 = useReveal();
  const r3 = useReveal();
  const r4 = useReveal();
  const r5 = useReveal();

  const stageRef = useRef(null);
  const phoneRef = useRef(null);
  const [activeColor, setActiveColor] = useState(COLORS[0].hex);

  function handleMouseMove(e) {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const rect = stageRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    phoneRef.current.style.transform = `rotateY(${x * 16}deg) rotateX(${-y * 16}deg)`;
  }
  function handleMouseLeave() {
    phoneRef.current.style.transform = "rotateY(0deg) rotateX(0deg)";
  }

  const whatsapp = process.env.NEXT_PUBLIC_WHATSAPP;

  return (
    <>
      <section className="hero">
        <div>
          <div className="eyebrow reveal in" ref={r1}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M20 6L9 17l-5-5" />
            </svg>
            Garantia real de 90 dias
          </div>
          <h1 className="reveal in" ref={r2}>
            iPhones seminovos que parecem <span>novos de novo</span>.
          </h1>
          <p className="lead reveal in" ref={r3}>
            Do iPhone 11 ao 16 Pro Max, revisados, testados e com garantia. Escolha pelo
            site e pague com Pix, cartão ou boleto — direto por aqui.
          </p>
          <div className="hero-ctas reveal in" ref={r4}>
            <a href="#catalogo" className="btn btn-primary">
              Ver catálogo
            </a>
            <a
              className="btn btn-ghost"
              href={waLink(whatsapp, "Olá! Vim pelo site e quero saber mais sobre os iPhones disponíveis.")}
              target="_blank"
              rel="noreferrer"
            >
              <WhatsAppIcon />
              Falar com um vendedor
            </a>
          </div>
          <div className="hero-stats reveal in" ref={r5}>
            <div>
              <b>+1.200</b>
              <span>iPhones entregues</span>
            </div>
            <div>
              <b>90 dias</b>
              <span>de garantia</span>
            </div>
            <div>
              <b>Todo o BR</b>
              <span>entrega via transportadora</span>
            </div>
          </div>
        </div>

        <div
          className="stage"
          ref={stageRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          <div className="glow" style={{ background: `radial-gradient(circle, ${activeColor}, transparent 70%)` }}></div>
          <div className="phone" ref={phoneRef}>
            <div
              className="screen-glow"
              style={{
                background: `conic-gradient(from 180deg, ${activeColor}, transparent 40%, var(--accent-2) 70%, transparent 100%)`,
              }}
            ></div>
            <div className="island"></div>
            <div className="price-tag">
              <b>R$ 3.699</b>
              <span>iPhone 15 · 128GB</span>
            </div>
          </div>
        </div>
      </section>

      <div className="wrap">
        <div className="swatches">
          {COLORS.map((c) => (
            <div
              key={c.hex}
              className={`swatch ${activeColor === c.hex ? "active" : ""}`}
              style={{ background: c.hex }}
              title={c.name}
              onClick={() => setActiveColor(c.hex)}
            />
          ))}
        </div>
      </div>
    </>
  );
}
