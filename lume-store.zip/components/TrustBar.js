export default function TrustBar() {
  return (
    <div className="trust">
      <div className="wrap">
        <div className="trust-item">
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2"><path d="M12 2l8 4v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6l8-4z" /></svg>
          Aparelhos revisados em +40 pontos
        </div>
        <div className="trust-item">
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2"><rect x="1" y="6" width="18" height="12" rx="2" /><path d="M19 10h4v5h-4" /></svg>
          Entrega para todo o Brasil
        </div>
        <div className="trust-item">
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2"><path d="M12 2C6.5 2 2 6.5 2 12c0 1.9.5 3.6 1.5 5.2L2 22l4.9-1.5C8.4 21.5 10.1 22 12 22c5.5 0 10-4.5 10-10S17.5 2 12 2z" /></svg>
          Pagamento seguro (Pix, cartão e boleto)
        </div>
        <div className="trust-item">
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2"><path d="M20 6L9 17l-5-5" /></svg>
          Nota fiscal e garantia de 90 dias
        </div>
      </div>
    </div>
  );
}
