import { PRODUCTS } from "@/data/products";
import ProductCard from "./ProductCard";

export default function CatalogSection() {
  return (
    <section className="section" id="catalogo">
      <div className="wrap">
        <div className="section-head">
          <div className="eyebrow">Catálogo</div>
          <h2>Escolha o modelo, o armazenamento e adicione ao carrinho</h2>
          <p>Todos os aparelhos são seminovos, com bateria acima de 85% de saúde e nota fiscal.</p>
        </div>
        <div className="catalog-grid">
          {PRODUCTS.map((p) => (
            <ProductCard key={p.slug} product={p} />
          ))}
        </div>
      </div>
    </section>
  );
}
