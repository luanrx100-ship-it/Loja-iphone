"use client";

import { useCart } from "@/context/CartContext";

export default function Header() {
  const { count, setIsOpen } = useCart();

  return (
    <header className="site-header">
      <nav className="main-nav">
        <div className="logo">
          <span className="logo-dot"></span>LUME
        </div>
        <div className="nav-links">
          <a href="#catalogo">Catálogo</a>
          <a href="#como-funciona">Como funciona</a>
          <a href="#garantia">Garantia</a>
          <a href="#faq">Dúvidas</a>
        </div>
        <div className="nav-right">
          <button
            className="cart-btn"
            onClick={() => setIsOpen(true)}
            aria-label="Abrir carrinho"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="9" cy="21" r="1" />
              <circle cx="20" cy="21" r="1" />
              <path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6" />
            </svg>
            {count > 0 && <span className="cart-count">{count}</span>}
          </button>
        </div>
      </nav>
    </header>
  );
}
