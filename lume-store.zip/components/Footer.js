"use client";

import WhatsAppIcon, { waLink } from "./WhatsAppIcon";

export default function Footer() {
  const whatsapp = process.env.NEXT_PUBLIC_WHATSAPP;

  return (
    <>
      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-grid">
            <div>
              <div className="logo">
                <span className="logo-dot"></span>LUME
              </div>
              <p>iPhones seminovos revisados, com garantia e entrega para todo o Brasil.</p>
            </div>
            <div className="footer-col">
              <h4>Loja</h4>
              <a href="#catalogo">Catálogo</a>
              <a href="#como-funciona">Como funciona</a>
              <a href="#garantia">Garantia</a>
            </div>
            <div className="footer-col">
              <h4>Fale com a gente</h4>
              <a href={waLink(whatsapp, "Olá! Quero falar com um vendedor da LUME.")} target="_blank" rel="noreferrer">
                WhatsApp
              </a>
              <a href="#">Instagram</a>
            </div>
          </div>
          <div className="footer-bottom">
            © 2026 LUME iPhones. Todos os aparelhos são revisados e testados antes do envio.
          </div>
        </div>
      </footer>

      <a
        className="float-wa"
        href={waLink(whatsapp, "Olá! Vim pelo site da LUME e quero saber mais.")}
        target="_blank"
        rel="noreferrer"
        aria-label="Falar no WhatsApp"
      >
        <WhatsAppIcon size={28} />
      </a>
    </>
  );
}
