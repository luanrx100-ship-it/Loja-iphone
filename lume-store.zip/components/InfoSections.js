"use client";

import WhatsAppIcon, { waLink } from "./WhatsAppIcon";

export function HowItWorks() {
  return (
    <section
      className="section"
      id="como-funciona"
      style={{ background: "var(--bg-elev)", borderTop: "1px solid var(--line)", borderBottom: "1px solid var(--line)" }}
    >
      <div className="wrap">
        <div className="section-head">
          <div className="eyebrow">Como funciona</div>
          <h2>Da escolha até a porta da sua casa</h2>
        </div>
        <div className="steps">
          <div className="step">
            <div className="num">01</div>
            <h3>Escolha no site</h3>
            <p>Veja modelo, cor e armazenamento disponíveis e o preço já atualizado.</p>
          </div>
          <div className="step">
            <div className="num">02</div>
            <h3>Pague com segurança</h3>
            <p>Finalize o pedido com Pix, cartão ou boleto direto pelo checkout — sem sair do site.</p>
          </div>
          <div className="step">
            <div className="num">03</div>
            <h3>Receba em casa</h3>
            <p>Envio rastreado por transportadora para qualquer cidade do Brasil, com nota fiscal e garantia.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Guarantee() {
  const whatsapp = process.env.NEXT_PUBLIC_WHATSAPP;
  return (
    <section className="section" id="garantia">
      <div className="wrap">
        <div className="guarantee">
          <h2>90 dias de garantia em toda a loja</h2>
          <p>
            Se o aparelho apresentar qualquer defeito de fábrica ou da revisão, trocamos ou
            consertamos sem custo. Você compra sabendo que tem suporte depois da entrega.
          </p>
          <a
            className="btn btn-primary"
            href={waLink(whatsapp, "Olá! Tenho uma dúvida sobre a garantia dos iPhones.")}
            target="_blank"
            rel="noreferrer"
          >
            <WhatsAppIcon />
            Tirar dúvidas no WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
