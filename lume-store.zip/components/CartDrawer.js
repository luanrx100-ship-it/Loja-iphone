"use client";

import { useRouter } from "next/navigation";
import { useCart } from "@/context/CartContext";

function money(n) {
  return "R$ " + n.toLocaleString("pt-BR");
}

export default function CartDrawer() {
  const { items, isOpen, setIsOpen, updateQty, removeItem, total } = useCart();
  const router = useRouter();

  function handleCheckout() {
    setIsOpen(false);
    router.push("/checkout");
  }

  return (
    <>
      <div className={`overlay ${isOpen ? "open" : ""}`} onClick={() => setIsOpen(false)} />
      <aside className={`drawer ${isOpen ? "open" : ""}`}>
        <div className="drawer-head">
          <h3>Seu carrinho</h3>
          <button className="drawer-close" onClick={() => setIsOpen(false)} aria-label="Fechar carrinho">
            ×
          </button>
        </div>

        <div className="drawer-items">
          {items.length === 0 && <div className="drawer-empty">Seu carrinho está vazio.</div>}
          {items.map((item) => (
            <div className="drawer-item" key={item.id}>
              <div>
                <div className="title">{item.title}</div>
                <div className="price">{money(item.price)}</div>
              </div>
              <div className="qty-controls">
                <button onClick={() => updateQty(item.id, item.qty - 1)}>−</button>
                <span>{item.qty}</span>
                <button onClick={() => updateQty(item.id, item.qty + 1)}>+</button>
              </div>
            </div>
          ))}
        </div>

        {items.length > 0 && (
          <div className="drawer-footer">
            <div className="total-row">
              <span>Total</span>
              <span>{money(total)}</span>
            </div>
            <button className="btn btn-primary btn-block" onClick={handleCheckout}>
              Finalizar compra
            </button>
          </div>
        )}
      </aside>
    </>
  );
}
