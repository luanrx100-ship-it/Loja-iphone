"use client";

import { useState } from "react";
import { useCart } from "@/context/CartContext";
import { useReveal } from "./useReveal";

function money(n) {
  return "R$ " + n.toLocaleString("pt-BR");
}

export default function ProductCard({ product }) {
  const ref = useReveal();
  const { addItem } = useCart();
  const [storageIndex, setStorageIndex] = useState(0);
  const [justAdded, setJustAdded] = useState(false);

  const storage = product.storages[storageIndex];
  const itemId = `${product.slug}__${storage.gb}`;

  function handleAdd() {
    addItem({
      id: itemId,
      title: `${product.model} ${storage.gb}`,
      price: storage.price,
    });
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1500);
  }

  return (
    <div className="card reveal in" ref={ref}>
      {product.badge && <div className="badge">{product.badge}</div>}
      <div className="mini-phone"></div>
      <h3>{product.model}</h3>
      <div className="desc">Seminovo revisado · bateria +85% · garantia de 90 dias</div>
      <select
        value={storageIndex}
        onChange={(e) => setStorageIndex(Number(e.target.value))}
      >
        {product.storages.map((s, i) => (
          <option key={s.gb} value={i}>
            {s.gb}
          </option>
        ))}
      </select>
      <div className="price-row">
        <span className="price">{money(storage.price)}</span>
        <span className="installments">até 12x no cartão</span>
      </div>
      <button className="btn btn-primary btn-block" onClick={handleAdd}>
        {justAdded ? "Adicionado ✓" : "Adicionar ao carrinho"}
      </button>
    </div>
  );
}
