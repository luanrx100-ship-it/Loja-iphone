"use client";

import { useState } from "react";

const FAQS = [
  { q: "Os aparelhos são originais?", a: "Sim. Todos os iPhones são originais Apple, seminovos, revisados internamente antes de qualquer envio." },
  { q: "Como funciona a garantia de 90 dias?", a: "Qualquer defeito de fábrica ou de revisão dentro desse prazo é resolvido sem custo — troca ou conserto, conforme o caso." },
  { q: "Vocês entregam em todo o Brasil?", a: "Sim, enviamos por transportadora com rastreamento para qualquer cidade do país." },
  { q: "Como faço para comprar?", a: "Adicione o modelo desejado ao carrinho, finalize o pedido e pague com Pix, cartão ou boleto direto no checkout." },
  { q: "Quais formas de pagamento vocês aceitam?", a: "Pix, cartão de crédito (em até 12x) e boleto, processados com segurança pelo Mercado Pago." },
];

export default function FaqSection() {
  const [openIndex, setOpenIndex] = useState(null);

  return (
    <section className="section" id="faq">
      <div className="wrap" style={{ maxWidth: "720px" }}>
        <div className="section-head">
          <div className="eyebrow">Dúvidas frequentes</div>
          <h2>Antes de comprar</h2>
        </div>
        <div>
          {FAQS.map((f, i) => (
            <div key={f.q} className={`faq-item ${openIndex === i ? "open" : ""}`}>
              <div className="faq-q" onClick={() => setOpenIndex(openIndex === i ? null : i)}>
                {f.q} <span className="plus">+</span>
              </div>
              <div className="faq-a">{f.a}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
