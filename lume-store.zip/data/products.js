// Catálogo central da loja.
// Para adicionar/editar aparelhos, mexa só neste arquivo.
// "id" precisa ser único (é usado no carrinho e no checkout).

export const PRODUCTS = [
  {
    slug: "iphone-11",
    model: "iPhone 11",
    badge: "Entrada",
    storages: [
      { gb: "64GB", price: 1699 },
      { gb: "128GB", price: 1899 },
    ],
  },
  {
    slug: "iphone-12",
    model: "iPhone 12",
    storages: [
      { gb: "64GB", price: 2099 },
      { gb: "128GB", price: 2299 },
    ],
  },
  {
    slug: "iphone-12-pro",
    model: "iPhone 12 Pro",
    storages: [
      { gb: "128GB", price: 2699 },
      { gb: "256GB", price: 2999 },
    ],
  },
  {
    slug: "iphone-13",
    model: "iPhone 13",
    badge: "Mais vendido",
    storages: [
      { gb: "128GB", price: 2899 },
      { gb: "256GB", price: 3199 },
    ],
  },
  {
    slug: "iphone-13-pro",
    model: "iPhone 13 Pro",
    storages: [
      { gb: "128GB", price: 3399 },
      { gb: "256GB", price: 3699 },
    ],
  },
  {
    slug: "iphone-14",
    model: "iPhone 14",
    storages: [
      { gb: "128GB", price: 3199 },
      { gb: "256GB", price: 3499 },
    ],
  },
  {
    slug: "iphone-14-pro",
    model: "iPhone 14 Pro",
    storages: [
      { gb: "128GB", price: 3999 },
      { gb: "256GB", price: 4399 },
    ],
  },
  {
    slug: "iphone-15",
    model: "iPhone 15",
    badge: "Destaque",
    storages: [
      { gb: "128GB", price: 3699 },
      { gb: "256GB", price: 3999 },
    ],
  },
  {
    slug: "iphone-15-pro",
    model: "iPhone 15 Pro",
    storages: [
      { gb: "128GB", price: 4799 },
      { gb: "256GB", price: 5199 },
    ],
  },
  {
    slug: "iphone-16",
    model: "iPhone 16",
    storages: [
      { gb: "128GB", price: 4499 },
      { gb: "256GB", price: 4899 },
    ],
  },
  {
    slug: "iphone-16-pro",
    model: "iPhone 16 Pro",
    badge: "Top de linha",
    storages: [
      { gb: "256GB", price: 5799 },
      { gb: "512GB", price: 6499 },
    ],
  },
];

// Helper: encontra um item exato (modelo + armazenamento) pelo id combinado "slug__gb"
export function findVariant(itemId) {
  const [slug, gb] = itemId.split("__");
  const product = PRODUCTS.find((p) => p.slug === slug);
  if (!product) return null;
  const storage = product.storages.find((s) => s.gb === gb);
  if (!storage) return null;
  return { product, storage };
}
