# LUME — Loja de iPhones Seminovos

Loja construída em **Next.js**, com carrinho de compras e checkout integrado ao
**Mercado Pago** (Pix, cartão e boleto).

## Estrutura

```
app/               páginas (home, checkout, sucesso/falha/pendente, rota de API)
components/        componentes visuais (header, hero, catálogo, carrinho...)
context/           estado global do carrinho
data/products.js   catálogo de produtos — edite aqui preços e modelos
lib/mercadopago.js cliente do Mercado Pago
```

## 1. Rodar localmente

Você vai precisar do [Node.js](https://nodejs.org) instalado (versão 18 ou mais recente).

```bash
npm install
cp .env.example .env.local
```

Abra `.env.local` e preencha:

- `MP_ACCESS_TOKEN` — pegue em https://www.mercadopago.com.br/developers/panel/app
  (crie uma aplicação gratuita; use o **token de teste** primeiro, depois troque pelo
  de produção quando for vender de verdade).
- `NEXT_PUBLIC_WHATSAPP` — seu número com DDI+DDD, só números (ex: 5511995931362).
- `NEXT_PUBLIC_URL` — deixe `http://localhost:3000` em desenvolvimento.

Depois:

```bash
npm run dev
```

Acesse http://localhost:3000

## 2. Editar produtos e preços

Tudo fica em `data/products.js`. Cada iPhone tem um `slug`, `model`, `badge` (opcional)
e uma lista de `storages` com armazenamento e preço. É só editar os números — o site,
o carrinho e o checkout se atualizam sozinhos.

## 3. Publicar na Vercel

1. Crie um repositório no GitHub e suba esta pasta nele (ou use `vercel` via CLI direto
   desta pasta, sem precisar do GitHub).
2. Entre em https://vercel.com, clique em **New Project** e importe o repositório.
3. Em **Environment Variables**, adicione as três variáveis do `.env.example`
   (com os valores reais, incluindo o `MP_ACCESS_TOKEN` de produção e o
   `NEXT_PUBLIC_URL` com o domínio final, ex: `https://lume-iphones.vercel.app`).
4. Clique em **Deploy**.

A cada alteração que você mandar para o repositório, a Vercel republica sozinha.

## 4. Como o pagamento funciona

- O cliente monta o carrinho no site (fica salvo no navegador dele).
- Ao clicar em "Pagar", o site chama `/api/create-preference`, que roda no servidor,
  **recalcula os preços a partir do catálogo** (nunca confia no que vem do navegador)
  e cria uma "preferência de pagamento" no Mercado Pago.
- O cliente é redirecionado para o checkout oficial do Mercado Pago (hospedado por
  eles — você não lida com dados de cartão).
- Depois do pagamento, ele volta para `/success`, `/failure` ou `/pending`, conforme
  o resultado.

### Próximo passo recomendado: webhook de confirmação

Hoje a loja confia no redirecionamento de volta do Mercado Pago para saber que o
pagamento foi aprovado. Para um controle mais robusto (ex: disparar automaticamente
uma notificação interna, marcar pedido como pago no seu sistema), o ideal é configurar
um **webhook** no painel do Mercado Pago apontando para uma nova rota de API
(`/api/webhook`), que ainda não existe neste projeto — posso montar essa parte quando
você tiver uma forma de registrar pedidos (banco de dados ou planilha, por exemplo).

## 5. O que ainda é manual

- Como não existe banco de dados neste projeto, os pedidos não ficam salvos em
  lugar nenhum além do próprio Mercado Pago (você vê os pagamentos no painel deles).
  Se quiser um histórico de pedidos dentro do site, é o próximo passo natural.
- O envio/rastreio continua sendo combinado por fora (WhatsApp, por exemplo),
  a loja não gera etiqueta de transportadora automaticamente.
