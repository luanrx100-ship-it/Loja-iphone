import "./globals.css";
import { CartProvider } from "@/context/CartContext";

export const metadata = {
  title: "LUME — iPhones Seminovos com Garantia",
  description:
    "iPhones seminovos revisados, do 11 ao 16 Pro, com garantia de 90 dias e entrega para todo o Brasil.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="true"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  );
}
