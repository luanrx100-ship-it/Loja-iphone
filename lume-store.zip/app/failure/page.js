import Link from "next/link";

export default function FailurePage() {
  return (
    <div className="status-wrap">
      <h1>Pagamento não concluído</h1>
      <p>
        Algo deu errado ou o pagamento foi cancelado. Nenhum valor foi cobrado. Você pode
        tentar novamente quando quiser.
      </p>
      <Link href="/checkout" className="btn btn-primary">
        Tentar novamente
      </Link>
    </div>
  );
}
