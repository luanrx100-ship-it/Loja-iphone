"use client";

import { useEffect } from "react";
import Link from "next/link";
import { useCart } from "@/context/CartContext";

export default function SuccessPage() {
  const { clearCart } = useCart();

  useEffect(() => {
    clearCart();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="status-wrap">
      <h1>Pagamento aprovado 🎉</h1>
      <p>
        Seu pedido foi confirmado! Em instantes você recebe os detalhes da entrega pelo
        WhatsApp cadastrado no pagamento.
      </p>
      <Link href="/" className="btn btn-primary">
        Voltar para a loja
      </Link>
    </div>
  );
}
