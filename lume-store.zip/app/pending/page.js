import Link from "next/link";

export default function PendingPage() {
  return (
    <div className="status-wrap">
      <h1>Pagamento em análise</h1>
      <p>
        Recebemos seu pedido e estamos aguardando a confirmação do pagamento (comum em boleto
        ou Pix ainda não compensado). Avisamos assim que for aprovado.
      </p>
      <Link href="/" className="btn btn-primary">
        Voltar para a loja
      </Link>
    </div>
  );
}
