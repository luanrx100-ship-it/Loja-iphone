import Header from "@/components/Header";
import Hero from "@/components/Hero";
import TrustBar from "@/components/TrustBar";
import CatalogSection from "@/components/CatalogSection";
import { HowItWorks, Guarantee } from "@/components/InfoSections";
import FaqSection from "@/components/FaqSection";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";

export default function Home() {
  return (
    <>
      <Header />
      <Hero />
      <TrustBar />
      <CatalogSection />
      <HowItWorks />
      <Guarantee />
      <FaqSection />
      <Footer />
      <CartDrawer />
    </>
  );
}
