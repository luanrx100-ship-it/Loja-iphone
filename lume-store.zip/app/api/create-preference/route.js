import { NextResponse } from "next/server";
import { Preference } from "mercadopago";
import { mpClient } from "@/lib/mercadopago";
import { findVariant } from "@/data/products";

// Recebe os itens do carrinho do cliente, mas SEMPRE recalcula o preço
// a partir do catálogo no servidor — nunca confia no preço vindo do navegador.
export async function POST(req) {
  try {
    const body = await req.json();
    const cartItems = body.items || [];

    if (!cartItems.length) {
      return NextResponse.json({ error: "Carrinho vazio" }, { status: 400 });
    }

    const preferenceItems = [];

    for (const cartItem of cartItems) {
      const variant = findVariant(cartItem.id);
      if (!variant) {
        return NextResponse.json(
          { error: `Item inválido: ${cartItem.id}` },
          { status: 400 }
        );
      }
      preferenceItems.push({
        id: cartItem.id,
        title: `${variant.product.model} ${variant.storage.gb}`,
        quantity: cartItem.qty,
        unit_price: variant.storage.price,
        currency_id: "BRL",
      });
    }

    const baseUrl = process.env.NEXT_PUBLIC_URL || "http://localhost:3000";

    const preference = new Preference(mpClient);
    const result = await preference.create({
      body: {
        items: preferenceItems,
        back_urls: {
          success: `${baseUrl}/success`,
          failure: `${baseUrl}/failure`,
          pending: `${baseUrl}/pending`,
        },
        auto_return: "approved",
        statement_descriptor: "LUME IPHONES",
      },
    });

    return NextResponse.json({
      id: result.id,
      init_point: result.init_point,
    });
  } catch (err) {
    console.error("Erro ao criar preferência Mercado Pago:", err);
    return NextResponse.json(
      { error: "Não foi possível iniciar o pagamento. Tente novamente." },
      { status: 500 }
    );
  }
}
