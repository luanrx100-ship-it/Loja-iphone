"use client";

import { useState } from "react";
import { useCart } from "@/context/CartContext";
import Header from "@/components/Header";
import CartDrawer from "@/components/CartDrawer";

function money(n) {
  return "R$ " + n.toLocaleString("pt-BR");
}

export default function CheckoutPage() {
  const { items, total } = useCart();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function handlePay() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/create-preference", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((i) => ({ id: i.id, qty: i.qty })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erro ao iniciar pagamento");
      // Leva o cliente para a página segura de pagamento do Mercado Pago
      window.location.href = data.init_point;
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <>
      <Header />
      <div className="checkout-wrap">
        <h1>Finalizar compra</h1>

        {items.length === 0 ? (
          <p style={{ color: "var(--text-dim)" }}>Seu carrinho está vazio.</p>
        ) : (
          <>
            {items.map((item) => (
              <div className="checkout-row" key={item.id}>
                <span>
                  {item.title} × {item.qty}
                </span>
                <span>{money(item.price * item.qty)}</span>
              </div>
            ))}
            <div className="checkout-total">
              <span>Total</span>
              <span>{money(total)}</span>
            </div>

            <button className="btn btn-primary btn-block" onClick={handlePay} disabled={loading}>
              {loading ? "Redirecionando…" : "Pagar com Pix, cartão ou boleto"}
            </button>

            {error && (
              <p style={{ color: "#ff8080", marginTop: "14px", fontSize: "14px" }}>{error}</p>
            )}

            <p className="checkout-note">
              Você será redirecionado para o ambiente seguro do Mercado Pago para concluir o
              pagamento. Depois da confirmação, você volta automaticamente para a LUME.
            </p>
          </>
        )}
      </div>
      <CartDrawer />
    </>
  );
}
